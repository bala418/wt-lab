const dateTime = require("./DateTime");

console.log("Current dateTime: " + dateTime());
