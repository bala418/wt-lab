const getDateTime = () => new Date();
module.exports = getDateTime;
