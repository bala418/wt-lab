public class EvenNos {
    public static void main(String[] args) {
        System.out.println("Even nos. between 1 & 50 divisible");
        for (int i = 2; i < 50; i += 2) {
            System.out.print(i + " ");
        }
    }
}
